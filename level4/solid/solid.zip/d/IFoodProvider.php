<?php

interface IFoodProvider
{
    public function getFood();
}
