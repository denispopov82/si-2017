<?php

/**
 * ${CLASS_NAME}
 *
 * @package   ${PARAM_DOC}
 */
class Restaurant implements IFoodProvider
{
    public function getFood()
    {
        return 'food';
    }
}
