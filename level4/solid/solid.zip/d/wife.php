<?php
/**
 * ${CLASS_NAME}
 *
 * @package   ${PARAM_DOC}
 */
class Wife
{
    public function getFood()
    {
        return 'food';
    }
}

//class Wife implements IFoodProvider
//{
//    public function getFood ()
//    {
//        return 'food';
//    }
//}
