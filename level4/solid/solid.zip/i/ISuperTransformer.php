<?php
interface ISuperTransformer
{
    public function toCar();
    public function toPlane();
    public function toShip();
}
