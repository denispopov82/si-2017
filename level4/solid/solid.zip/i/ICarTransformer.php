<?php

/**
 * ${CLASS_NAME}
 *
 * @package   ${PARAM_DOC}
 */
interface ICarTransformer
{
    public function toCar();
}
