<?php

/**
 * ${CLASS_NAME}
 *
 * @package   ${PARAM_DOC}
 */
interface IPlaneTransformer
{
    public function toPlane();
}
