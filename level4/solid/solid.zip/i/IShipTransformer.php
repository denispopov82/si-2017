<?php

/**
 * ${CLASS_NAME}
 *
 * @package   ${PARAM_DOC}
 */
interface IShipTransformer
{
    public function toShip();
}
